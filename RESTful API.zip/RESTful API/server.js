const express = require('express');
const app = express();

app.use(express.json()); 

let users = [
    { id: 1, name: "Item 1", price: 100 },
    { id: 2, name: "Item 2", price: 200 }
];

app.get('/users', (req, res) => {
    res.json(users);
});

app.post('/users', (req, res) => {
    const newItem = req.body;
    newItem.id = users.length + 1;
    users.push(newItem);
    res.status(201).json(newItem);
});

app.put('/users/:id', (req, res) => {
    const itemId = parseInt(req.params.id);
    let item = users.find(i => i.id === itemId);

    if (!item) return res.status(404).send('Item not found');

    item.name = req.body.name;
    item.price = req.body.price;
    res.json(item);
});

app.delete('/users/:id', (req, res) => {
    users = users.filter(i => i.id !== parseInt(req.params.id));
    res.json({ message: 'Item deleted' });
});

app.listen(3000, () => console.log('https://localhost:3000'));
