// Import Required Modules
const express = require('express');
const morgan = require('morgan');
const helmet = require('helmet');
const bodyParser = require('body-parser');
const cors = require('cors');

// Create an Express App
const app = express();

// ✅ Middleware Setup
app.use(morgan('dev'));         
app.use(helmet());                
app.use(bodyParser.json());       
app.use(cors());                  
// ✅ Sample Route
app.get('/', (req, res) => {
    res.send('Welcome to the Express Server with Third-Party Extensions!');
});

// ✅ API Route to Test Body-Parser
app.post('/data', (req, res) => {
    res.json({ message: 'Data received successfully', data: req.body });
});

// ✅ Start the Server
const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
