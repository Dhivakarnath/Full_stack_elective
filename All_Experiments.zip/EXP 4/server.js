const express = require('express');
const app = express();

app.use(express.json());

let users = [
    { id: 1, name: "Alice", age: 25 },
    { id: 2, name: "Bob", age: 30 }
];

app.get('/', (req, res) => {
    res.send('Welcome to the User API! Use /users to get data.');
});
app.get('/users', (req, res) => {
    res.json(users);
});

app.post('/users', (req, res) => {
    const { id, name, age } = req.body;
    if (!id || !name || !age) {
        return res.status(400).json({ error: 'id, name and age are required' });
    }

    const exists = users.find(u => u.id === id);
    if (exists) {
        return res.status(409).json({ error: 'User with this ID already exists' });
    }

    const newUser = { id, name, age };
    users.push(newUser);
    res.status(201).json(newUser);
});

app.put('/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    const { name, age } = req.body;

    const user = users.find(u => u.id === userId);
    if (!user) {
        return res.status(404).json({ error: 'User not found' });
    }

    if (name) user.name = name;
    if (age) user.age = age;

    res.json(user);
});

app.delete('/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    const initialLength = users.length;
    users = users.filter(u => u.id !== userId);

    if (users.length === initialLength) {
        return res.status(404).json({ error: 'User not found' });
    }

    res.json({ message: 'User deleted' });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
