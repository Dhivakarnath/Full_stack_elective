const express = require('express');
const app = express();
const port = 3000;

// Sample JSON data
const users = [
  { id: 1, name: 'Alice', role: 'Developer' },
  { id: 2, name: 'Bob', role: 'Designer' },
  { id: 3, name: 'Charlie', role: 'Manager' }
];

// Root route
app.get('/', (req, res) => {
  res.send('Welcome to the API!');
});

// Route to get all users
app.get('/api/users', (req, res) => {
  res.json(users);
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});