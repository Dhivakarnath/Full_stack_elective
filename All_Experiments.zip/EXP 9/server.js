const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const passport = require('passport');
const flash = require('connect-flash');
const bcrypt = require('bcrypt');
const LocalStrategy = require('passport-local').Strategy;

const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/', { useNewUrlParser: true, useUnifiedTopology: true });

// Define User Schema
const UserSchema = new mongoose.Schema({
    username: String,
    password: String
});

const User = mongoose.model('User', UserSchema);

// Middleware Setup
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: false }));
app.use(session({
    secret: 'mysecret',
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());

// Passport Authentication Strategy
passport.use(new LocalStrategy(async (username, password, done) => {
    const user = await User.findOne({ username: username });
    if (!user) return done(null, false, { message: 'User not found' });
    
    const isMatch = await bcrypt.compare(password, user.password);
    return isMatch ? done(null, user) : done(null, false, { message: 'Incorrect password' });
}));

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
    const user = await User.findById(id);
    done(null, user);
});

// Routes
app.get('/', (req, res) => res.render('home'));
app.get('/login', (req, res) => res.render('login', { message: req.flash('error') }));
app.get('/register', (req, res) => res.render('register'));
app.get('/dashboard', isAuthenticated, (req, res) => res.render('dashboard', { user: req.user }));
app.get('/logout', (req, res) => {
    req.logout(() => res.redirect('/'));
});

// Registration Route
app.post('/register', async (req, res) => {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    await User.create({ username: req.body.username, password: hashedPassword });
    res.redirect('/login');
});

// Login Route
app.post('/login', passport.authenticate('local', {
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureFlash: true
}));

// Authentication Middleware
function isAuthenticated(req, res, next) {
    return req.isAuthenticated() ? next() : res.redirect('/login');
}

// Start Server
app.listen(3000, () => console.log('Server running on http://localhost:3000'));
